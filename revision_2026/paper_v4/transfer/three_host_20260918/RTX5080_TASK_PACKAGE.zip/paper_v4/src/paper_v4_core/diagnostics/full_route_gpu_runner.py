"""Full-route (R4) runner with a selectable CPU or CUDA linearisation backend.

Independent module: it does not modify any file pinned by the G3 protocol.  The
closed-loop tick semantics are taken verbatim from
``gpu_closed_loop_runner.execute`` so that the two cannot drift apart; only the
start condition, the tick count and the protocol identity differ.

Starting point is the frozen initial condition (``initialize_state(model, SPEED)``
with zero steering, zero previous control, zero reference distance and zero beta),
which is exactly where ``post_r3_r4_runner.execute`` starts, so a CPU run of this
module is directly comparable with the historical 2 ms reference.

The shared ``execute`` path computes the per-tick configuration error with the same
definition as the R5 information runner.  This keeps ``max_e_g_m`` a genuinely
computed no-op comparison column instead of the historical literal-zero stub.
"""
from __future__ import annotations

import argparse
import json
import osqp
from pathlib import Path
import sys
import time

import numpy as np

from ..cli import save, sha
from ..e01_100m import DT, params
from ..pilot_runner import ROUTE_LENGTH, SPEED
from .gpu_closed_loop_runner import expanded_parameters, execute

SCHEMA = "R4-FULL-ROUTE-v1"
SCOPE = "R4_FULL_ROUTE"

REQUIRED_G3_VERDICTS = (
    "cpu_run_completed",
    "gpu_run_completed",
    "gpu_position_within_tolerance",
    "gpu_heading_within_tolerance",
    "gpu_force_peak_within_tolerance",
    "original_hard_gates_hold",
)
NOT_REQUIRED_G3_VERDICTS = ("restart_position_within_tolerance", "restart_heading_within_tolerance")


def validate_protocol(path: Path, expected_sha: str, paper: Path, parameter: str, backend: str) -> dict:
    if sha(path) != expected_sha.lower():
        raise ValueError("PROTOCOL_IDENTITY_MISMATCH")
    protocol = json.loads(path.read_text(encoding="utf-8"))
    if protocol.get("schema_version") != SCHEMA:
        raise ValueError("PROTOCOL_SCHEMA_MISMATCH")
    if protocol.get("scope") != SCOPE:
        raise ValueError("PROTOCOL_SCOPE_MISMATCH")
    for item in protocol["identity_files"]:
        source = paper / item["path"]
        if not source.is_file() or sha(source) != item["sha256"]:
            raise ValueError("IDENTITY_MISMATCH:" + item["path"])
    # Parent gates are enforced in code, not only asserted in prose.  The G3 report
    # deliberately keeps its restart_* verdicts FAILED, so the overall G3 status is
    # not PASS; what this runner requires is the set of verdicts the full route
    # actually depends on, and it re-checks both the required and the recorded-failed
    # sets against the live report so the protocol cannot quietly hide a change.
    g3 = paper / protocol["parent_g3"]["path"]
    g3_data = json.loads(g3.read_text(encoding="utf-8"))
    if sha(g3) != protocol["parent_g3"]["sha256"]:
        raise ValueError("PARENT_G3_IDENTITY_MISMATCH")
    live_required = {
        f"{window['window']}.{verdict}": bool(window["verdicts"].get(verdict))
        for window in g3_data["windows"]
        for verdict in REQUIRED_G3_VERDICTS
    }
    live_failed = {
        f"{window['window']}.{verdict}": bool(window["verdicts"].get(verdict))
        for window in g3_data["windows"]
        for verdict in NOT_REQUIRED_G3_VERDICTS
    }
    if live_required != protocol["parent_g3"]["required_verdicts"] or not all(live_required.values()):
        raise ValueError("PARENT_G3_REQUIRED_VERDICTS_NOT_MET")
    if live_failed != protocol["parent_g3"]["not_required_verdicts"]:
        raise ValueError("PARENT_G3_VERDICT_RECORD_MISMATCH")
    mechanism = paper / protocol["parent_g3b_mechanism"]["path"]
    mechanism_data = json.loads(mechanism.read_text(encoding="utf-8"))
    if sha(mechanism) != protocol["parent_g3b_mechanism"]["sha256"] or mechanism_data.get("status") != "PASS_READ_ONLY_MECHANISM_ANALYSIS":
        raise ValueError("PARENT_G3B_MECHANISM_NOT_PASS")
    qualification = paper / protocol["parent_qualification"]["path"]
    qualification_data = json.loads(qualification.read_text(encoding="utf-8"))
    if sha(qualification) != protocol["parent_qualification"]["sha256"] or qualification_data.get("status") != "PASS_G0_G2_GPU_QUALIFIED":
        raise ValueError("PARENT_QUALIFICATION_NOT_PASS")
    run = protocol["run"]
    resolve_solver_settings(protocol)
    resolve_acceptance_tolerances(protocol)
    if run["parameter_id"] != parameter or run["backend"] != backend:
        raise ValueError("RUN_IDENTITY_MISMATCH")
    if backend not in ("cpu", "gpu") or parameter not in ("P0", "P1", "P2"):
        raise ValueError("UNREGISTERED_RUN_CELL")
    model = params(parameter)
    if expanded_parameters(model) != protocol["absolute_parameters"]:
        raise ValueError("ABSOLUTE_PARAMETER_IDENTITY_MISMATCH")
    return protocol


SOLVER_SETTING_KEYS = ("eps_abs", "eps_rel", "scaled_termination", "max_iter", "polishing")


def resolve_solver_settings(protocol: dict) -> dict:
    """Read the five solver settings from the frozen protocol.

    A protocol that declares them must declare all five with the right types, otherwise the
    run is refused before any output is created.  A protocol that omits them (the historical
    R4/G3 protocols) falls back to the settings those runs actually used, and the metrics
    record that the values came from the runner fallback rather than the protocol.
    """
    declared = protocol.get("solver_settings")
    if declared is None:
        return {"settings": {"eps_abs": 2e-4, "eps_rel": 2e-4, "scaled_termination": False,
                             "max_iter": 4000, "polishing": True},
                "source": "runner_default_historical_protocol_omits_solver_settings"}
    if not isinstance(declared, dict) or set(declared) != set(SOLVER_SETTING_KEYS):
        raise ValueError("SOLVER_SETTINGS_MALFORMED:" + repr(sorted(declared) if isinstance(declared, dict) else declared))
    for key in ("eps_abs", "eps_rel"):
        if not isinstance(declared[key], (int, float)) or not (0.0 < float(declared[key]) < 1.0):
            raise ValueError("SOLVER_SETTINGS_OUT_OF_RANGE:" + key)
    for key in ("scaled_termination", "polishing"):
        if not isinstance(declared[key], bool):
            raise ValueError("SOLVER_SETTINGS_NOT_BOOLEAN:" + key)
    if not isinstance(declared["max_iter"], int) or declared["max_iter"] <= 0:
        raise ValueError("SOLVER_SETTINGS_OUT_OF_RANGE:max_iter")
    return {"settings": {key: declared[key] for key in SOLVER_SETTING_KEYS}, "source": "protocol"}


ACCEPTANCE_TOLERANCE_KEYS = (
    "requested_steering_acceptance_tolerance_rad",
    "applied_steering_machine_tolerance_rad",
)


def resolve_acceptance_tolerances(protocol: dict) -> dict | None:
    """Validate the two task-book tolerances independently of OSQP settings."""
    declared = protocol.get("acceptance_tolerances")
    if declared is None:
        if protocol.get("solver_settings") is not None:
            raise ValueError("ACCEPTANCE_TOLERANCES_MISSING")
        return None
    if not isinstance(declared, dict) or set(declared) != set(ACCEPTANCE_TOLERANCE_KEYS):
        raise ValueError("ACCEPTANCE_TOLERANCES_MALFORMED")
    for key in ACCEPTANCE_TOLERANCE_KEYS:
        value = declared[key]
        if not isinstance(value, (int, float)) or not np.isfinite(float(value)) or float(value) < 0.0:
            raise ValueError("ACCEPTANCE_TOLERANCE_OUT_OF_RANGE:" + key)
    return {key: float(declared[key]) for key in ACCEPTANCE_TOLERANCE_KEYS}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", required=True)
    parser.add_argument("--protocol-sha", required=True)
    parser.add_argument("--backend", choices=("cpu", "gpu"), required=True)
    parser.add_argument("--deadline-unix", type=float, required=True)
    args = parser.parse_args()
    paper = Path(__file__).resolve().parents[3]
    protocol_path = Path(args.protocol).resolve()
    declared = json.loads(protocol_path.read_text(encoding="utf-8"))["run"]["parameter_id"]
    protocol = validate_protocol(protocol_path, args.protocol_sha, paper, declared, args.backend)
    solver_resolution = resolve_solver_settings(protocol)
    solver_settings = solver_resolution["settings"]
    acceptance_tolerances = resolve_acceptance_tolerances(protocol)
    run = protocol["run"]
    parameter = run["parameter_id"]
    out = (paper / run["output"]).resolve()
    if out.exists():
        raise ValueError("REFUSING_TO_OVERWRITE_OUTPUT")

    model = params(parameter)
    from ..plant.four_vehicle_common import initialize_state

    count = int(np.ceil((ROUTE_LENGTH / SPEED) / DT))
    if count != int(run["total_ticks"]):
        raise ValueError("TICK_COUNT_MISMATCH")
    out.mkdir(parents=True)
    checkpoint_state = {
        "state": initialize_state(model, SPEED),
        "delta": np.zeros(4),
        "previous_u": np.zeros(8),
        "distance": 0.0,
        "beta": np.zeros(4),
        "source_row": None,
        "source_time_s": 0.0,
        "replay_closure": None,
    }
    save(out, "checkpoint_source.json", {
        "start": "frozen_initial_condition",
        "note": "identical to post_r3_r4_runner.execute: initialize_state(model, SPEED) with zero steering, zero previous control, zero distance and zero beta",
        "total_ticks": count,
        "backend": args.backend,
        "state": checkpoint_state["state"].tolist(),
    })
    window = {"name": "full_route", "start_tick": 0, "ticks": count, "plant_max_step_ms": float(run["plant_max_step_ms"]), "source_run": None}
    max_step_s = float(run["plant_max_step_ms"]) / 1000.0

    if args.backend == "cpu":
        from ..controllers.parallel_fd_backend import ParallelFiniteDifferenceBackend, install_parallel_linearization

        workers = int(run["workers"])
        with ParallelFiniteDifferenceBackend(workers) as backend:
            warmup = backend.warm(np.r_[checkpoint_state["state"], checkpoint_state["delta"]], np.zeros(8), model)
            save(out, "pool.json", {"workers": workers, "warmup_s": warmup})
            with install_parallel_linearization(backend):
                execute(
                    out, model, parameter, "cpu", window, checkpoint_state, max_step_s,
                    args.deadline_unix, args.protocol_sha.lower(), solver_settings,
                    acceptance_tolerances, solver_resolution["source"],
                )
    else:
        from ..gpu_port.ipc_backend import CudaIpcFiniteDifferenceBackend, install_cuda_linearization

        with CudaIpcFiniteDifferenceBackend(model) as backend:
            environment = backend.environment()
            warmup = backend.warm(np.r_[checkpoint_state["state"], checkpoint_state["delta"]], np.zeros(8))
            save(out, "pool.json", {
                "backend": "cuda", "device": environment.get("device_name"),
                "warmup_s": warmup, "worker_module_audit": environment.get("worker_module_audit"),
            })
            with install_cuda_linearization(backend):
                execute(
                    out, model, parameter, "gpu", window, checkpoint_state, max_step_s,
                    args.deadline_unix, args.protocol_sha.lower(), solver_settings,
                    acceptance_tolerances, solver_resolution["source"],
                )

    # Add the host-side environment and configuration provenance after the shared runner
    # has written its final metrics.  The numerical configuration error is already computed
    # by execute() and must not be overwritten here.
    metrics_path = out / "metrics.json"
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    metrics["environment"] = {
        "python": sys.executable,
        "version": sys.version.split()[0],
        "osqp": osqp.__version__,
        "numpy": np.__version__,
    }
    save(out, "metrics.json", metrics)
    status_path = out / "status.json"
    if status_path.is_file():
        status = json.loads(status_path.read_text(encoding="utf-8"))
        status.update({
            "maximum_configuration_error_m": metrics["maximum_configuration_error_m"],
            "solver_settings": metrics["solver_settings"],
            "solver_settings_effective": metrics["solver_settings_effective"],
            "solver_settings_source": metrics["solver_settings_source"],
            "acceptance_tolerances": metrics["acceptance_tolerances"],
            "environment": metrics["environment"],
        })
        save(out, "status.json", status)
    print(json.dumps({"out": str(out), "status": metrics["status"], "ticks": metrics["iterations"]}, ensure_ascii=False))


if __name__ == "__main__":
    sys.exit(main())
